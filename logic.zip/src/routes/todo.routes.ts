import { Router } from "express";
import { authenticate } from "../middleware/auth.middleware";
import { idempotency } from "../middleware/idempotency.middleware";
import { destroy, index, store, toggle, update } from "../controllers/todo.controller";
import { validate, validateParams } from "../middleware/validate.middleware";
import { createTodoSchema, updateTodoSchema, todoIdParamSchema } from "../validators/todo.validator";

const router = Router();

router.use(authenticate);

router.get("/", index);
router.post("/", idempotency, validate(createTodoSchema), store);
router.patch("/:id", idempotency, validate(updateTodoSchema), update);
router.patch("/:id/toggle", idempotency, validateParams(todoIdParamSchema), toggle);
router.delete("/:id", validateParams(todoIdParamSchema), destroy);

export default router;
